import { useState, useCallback } from 'react';
import { ContentBlock, BlogPost } from '../types';

export const useBlogState = () => {
  const [blogTitle, setBlogTitle] = useState('Untitled Masterpiece');
  const [blocks, setBlocks] = useState<ContentBlock[]>([]);
  const [isPreviewMode, setIsPreviewMode] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [isPublishing, setIsPublishing] = useState(false);

  const addBlock = useCallback((type: string) => {
    const newBlock: ContentBlock = {
      id: Date.now().toString(),
      type: type as ContentBlock['type'],
      content: '',
      order: blocks.length,
      styles: {},
    };
    setBlocks(prev => [...prev, newBlock]);
  }, [blocks.length]);

  const updateBlocks = useCallback((newBlocks: ContentBlock[]) => {
    setBlocks(newBlocks);
  }, []);

  const saveBlog = useCallback(async () => {
    setIsSaving(true);
    try {
      // Simulate API call with realistic delay
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      const blogPost: BlogPost = {
        id: Date.now().toString(),
        title: blogTitle,
        blocks: blocks,
        createdAt: new Date(),
        updatedAt: new Date(),
        published: false,
      };
      
      // Save to localStorage for demo
      const savedBlogs = JSON.parse(localStorage.getItem('luxuryBlogs') || '[]');
      const existingIndex = savedBlogs.findIndex((blog: BlogPost) => blog.title === blogTitle);
      
      if (existingIndex >= 0) {
        savedBlogs[existingIndex] = { ...blogPost, createdAt: savedBlogs[existingIndex].createdAt };
      } else {
        savedBlogs.push(blogPost);
      }
      
      localStorage.setItem('luxuryBlogs', JSON.stringify(savedBlogs));
      
      // Show success notification
      console.log('✨ Blog saved successfully to your premium collection!');
    } catch (error) {
      console.error('❌ Error saving blog:', error);
    } finally {
      setIsSaving(false);
    }
  }, [blogTitle, blocks]);

  const publishBlog = useCallback(async () => {
    setIsPublishing(true);
    try {
      // Simulate publishing process
      await new Promise(resolve => setTimeout(resolve, 3000));
      
      const blogPost: BlogPost = {
        id: Date.now().toString(),
        title: blogTitle,
        blocks: blocks,
        createdAt: new Date(),
        updatedAt: new Date(),
        published: true,
      };
      
      // Save published version
      const publishedBlogs = JSON.parse(localStorage.getItem('publishedBlogs') || '[]');
      publishedBlogs.push(blogPost);
      localStorage.setItem('publishedBlogs', JSON.stringify(publishedBlogs));
      
      console.log('🚀 Blog published successfully! Your masterpiece is now live.');
    } catch (error) {
      console.error('❌ Error publishing blog:', error);
    } finally {
      setIsPublishing(false);
    }
  }, [blogTitle, blocks]);

  const togglePreview = useCallback(() => {
    setIsPreviewMode(prev => !prev);
  }, []);

  const updateTitle = useCallback((title: string) => {
    setBlogTitle(title);
  }, []);

  return {
    blogTitle,
    blocks,
    isPreviewMode,
    isSaving,
    isPublishing,
    addBlock,
    updateBlocks,
    saveBlog,
    publishBlog,
    togglePreview,
    updateTitle,
  };
};