export interface ContentBlock {
  id: string;
  type: 'heading' | 'paragraph' | 'image' | 'quote' | 'list' | 'divider';
  content: string;
  order: number;
  styles?: {
    textAlign?: 'left' | 'center' | 'right';
    fontSize?: string;
    fontWeight?: string;
    color?: string;
  };
}

export interface BlogPost {
  id: string;
  title: string;
  blocks: ContentBlock[];
  createdAt: Date;
  updatedAt: Date;
  published: boolean;
}

export interface DragItem {
  id: string;
  type: string;
  index?: number;
}