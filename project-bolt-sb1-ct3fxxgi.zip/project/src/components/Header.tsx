import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Save, Eye, Settings, Crown, User, LogOut, Bell, Sparkles } from 'lucide-react';
import { User as UserType } from '../hooks/useAuth';

interface HeaderProps {
  onSave: () => void;
  onPreview: () => void;
  onPublish: () => void;
  onSettings: () => void;
  isPreviewMode: boolean;
  blogTitle: string;
  onTitleChange: (title: string) => void;
  user: UserType;
  onLogout: () => void;
  isSaving: boolean;
  isPublishing: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  onSave,
  onPreview,
  onPublish,
  onSettings,
  isPreviewMode,
  blogTitle,
  onTitleChange,
  user,
  onLogout,
  isSaving,
  isPublishing,
}) => {
  const [showUserMenu, setShowUserMenu] = useState(false);

  return (
    <header className="bg-white/95 backdrop-blur-md border-b border-gray-200/50 px-6 py-4 sticky top-0 z-40">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-6">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-gradient-to-br from-purple-600 to-blue-600 rounded-xl">
              <Crown className="w-6 h-6 text-white" />
            </div>
            <div>
              <span className="text-xl font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
                BlogCraft Elite
              </span>
              <div className="flex items-center space-x-1">
                <Sparkles className="w-3 h-3 text-purple-500" />
                <span className="text-xs text-purple-600 font-medium">{user.plan.toUpperCase()}</span>
              </div>
            </div>
          </div>
          
          <div className="hidden md:block w-px h-8 bg-gray-300" />
          
          <input
            type="text"
            value={blogTitle}
            onChange={(e) => onTitleChange(e.target.value)}
            className="hidden md:block text-lg font-semibold text-gray-900 bg-transparent border-none focus:outline-none focus:ring-0 max-w-xs placeholder-gray-400"
            placeholder="Untitled Masterpiece"
          />
        </div>
        
        <div className="flex items-center space-x-3">
          {/* Notifications */}
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="p-3 bg-gray-50 hover:bg-gray-100 rounded-xl transition-colors relative"
          >
            <Bell className="w-5 h-5 text-gray-600" />
            <div className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full" />
          </motion.button>

          {/* Preview Toggle */}
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={onPreview}
            className={`px-4 py-3 rounded-xl flex items-center space-x-2 font-medium transition-all ${
              isPreviewMode
                ? 'bg-gradient-to-r from-purple-100 to-blue-100 text-purple-700 shadow-md'
                : 'bg-gray-50 text-gray-700 hover:bg-gray-100'
            }`}
          >
            <Eye className="w-4 h-4" />
            <span className="hidden sm:inline">Preview</span>
          </motion.button>
          
          {/* Save Draft */}
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={onSave}
            disabled={isSaving}
            className="px-4 py-3 bg-gradient-to-r from-gray-600 to-gray-700 text-white rounded-xl hover:from-gray-700 hover:to-gray-800 transition-all flex items-center space-x-2 font-medium shadow-lg hover:shadow-xl disabled:opacity-50"
          >
            {isSaving ? (
              <>
                <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                <span className="hidden sm:inline">Saving...</span>
              </>
            ) : (
              <>
                <Save className="w-4 h-4" />
                <span className="hidden sm:inline">Save Draft</span>
              </>
            )}
          </motion.button>
          
          {/* Publish */}
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={onPublish}
            disabled={isPublishing}
            className="px-4 py-3 bg-gradient-to-r from-purple-600 to-blue-600 text-white rounded-xl hover:from-purple-700 hover:to-blue-700 transition-all flex items-center space-x-2 font-medium shadow-lg hover:shadow-xl disabled:opacity-50"
          >
            {isPublishing ? (
              <>
                <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                <span className="hidden sm:inline">Publishing...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4" />
                <span className="hidden sm:inline">Publish</span>
              </>
            )}
          </motion.button>

          {/* User Menu */}
          <div className="relative">
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => setShowUserMenu(!showUserMenu)}
              className="flex items-center space-x-3 p-2 hover:bg-gray-50 rounded-xl transition-colors"
            >
              <img
                src={user.avatar}
                alt={user.name}
                className="w-8 h-8 rounded-full object-cover ring-2 ring-purple-200"
              />
              <div className="hidden md:block text-left">
                <div className="text-sm font-medium text-gray-900">{user.name}</div>
                <div className="text-xs text-purple-600">{user.plan} Plan</div>
              </div>
            </motion.button>

            {showUserMenu && (
              <motion.div
                initial={{ opacity: 0, scale: 0.95, y: -10 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                className="absolute right-0 top-full mt-2 w-64 bg-white rounded-2xl shadow-2xl border border-gray-100 py-2 z-50"
              >
                <div className="px-4 py-3 border-b border-gray-100">
                  <div className="flex items-center space-x-3">
                    <img
                      src={user.avatar}
                      alt={user.name}
                      className="w-10 h-10 rounded-full object-cover"
                    />
                    <div>
                      <div className="font-medium text-gray-900">{user.name}</div>
                      <div className="text-sm text-gray-500">{user.email}</div>
                      <div className="flex items-center space-x-1 mt-1">
                        <Crown className="w-3 h-3 text-purple-500" />
                        <span className="text-xs text-purple-600 font-medium">{user.plan}</span>
                      </div>
                    </div>
                  </div>
                </div>
                
                <div className="py-2">
                  <button
                    onClick={() => {
                      onSettings();
                      setShowUserMenu(false);
                    }}
                    className="w-full px-4 py-2 text-left hover:bg-gray-50 flex items-center space-x-3 text-gray-700"
                  >
                    <Settings className="w-4 h-4" />
                    <span>Settings</span>
                  </button>
                  <button
                    onClick={() => {
                      onLogout();
                      setShowUserMenu(false);
                    }}
                    className="w-full px-4 py-2 text-left hover:bg-red-50 flex items-center space-x-3 text-red-600"
                  >
                    <LogOut className="w-4 h-4" />
                    <span>Sign Out</span>
                  </button>
                </div>
              </motion.div>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};