import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, User, Bell, Palette, Crown, Shield, Globe, Zap } from 'lucide-react';
import { User as UserType } from '../hooks/useAuth';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  user: UserType;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  user,
}) => {
  const [activeTab, setActiveTab] = useState('profile');

  const tabs = [
    { id: 'profile', label: 'Profile', icon: User },
    { id: 'notifications', label: 'Notifications', icon: Bell },
    { id: 'appearance', label: 'Appearance', icon: Palette },
    { id: 'billing', label: 'Billing', icon: Crown },
  ];

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4"
          onClick={onClose}
        >
          <motion.div
            initial={{ scale: 0.9, opacity: 0, y: 20 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0.9, opacity: 0, y: 20 }}
            transition={{ type: "spring", duration: 0.5 }}
            className="bg-white rounded-3xl shadow-2xl w-full max-w-4xl max-h-[90vh] overflow-hidden"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Header */}
            <div className="bg-gradient-to-r from-purple-600 to-blue-600 p-6 text-white">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className="p-2 bg-white/20 rounded-xl">
                    <Crown className="w-6 h-6" />
                  </div>
                  <div>
                    <h2 className="text-2xl font-bold">Premium Settings</h2>
                    <p className="text-white/80">Customize your luxury experience</p>
                  </div>
                </div>
                <button
                  onClick={onClose}
                  className="p-2 hover:bg-white/20 rounded-full transition-colors"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>
            </div>

            <div className="flex">
              {/* Sidebar */}
              <div className="w-64 bg-gray-50 p-6">
                <div className="space-y-2">
                  {tabs.map((tab) => {
                    const Icon = tab.icon;
                    return (
                      <button
                        key={tab.id}
                        onClick={() => setActiveTab(tab.id)}
                        className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl transition-all ${
                          activeTab === tab.id
                            ? 'bg-white shadow-md text-purple-600'
                            : 'text-gray-600 hover:bg-white/50'
                        }`}
                      >
                        <Icon className="w-5 h-5" />
                        <span className="font-medium">{tab.label}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Content */}
              <div className="flex-1 p-8 overflow-y-auto">
                {activeTab === 'profile' && (
                  <div className="space-y-6">
                    <h3 className="text-2xl font-bold text-gray-900">Profile Settings</h3>
                    
                    <div className="flex items-center space-x-6">
                      <img
                        src={user.avatar}
                        alt={user.name}
                        className="w-20 h-20 rounded-full object-cover ring-4 ring-purple-200"
                      />
                      <div>
                        <button className="px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors">
                          Change Avatar
                        </button>
                        <p className="text-sm text-gray-500 mt-1">JPG, PNG or GIF. Max 5MB.</p>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-6">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">Full Name</label>
                        <input
                          type="text"
                          defaultValue={user.name}
                          className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">Email</label>
                        <input
                          type="email"
                          defaultValue={user.email}
                          className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                        />
                      </div>
                    </div>

                    <div className="flex items-center justify-between p-4 bg-gradient-to-r from-purple-50 to-blue-50 rounded-xl border border-purple-200">
                      <div className="flex items-center space-x-3">
                        <Crown className="w-6 h-6 text-purple-600" />
                        <div>
                          <div className="font-semibold text-purple-900">{user.plan} Plan</div>
                          <div className="text-sm text-purple-600">Premium features enabled</div>
                        </div>
                      </div>
                      <button className="px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors">
                        Upgrade
                      </button>
                    </div>
                  </div>
                )}

                {activeTab === 'notifications' && (
                  <div className="space-y-6">
                    <h3 className="text-2xl font-bold text-gray-900">Notification Preferences</h3>
                    
                    <div className="space-y-4">
                      {[
                        { title: 'Email Notifications', desc: 'Receive updates via email' },
                        { title: 'Push Notifications', desc: 'Browser push notifications' },
                        { title: 'Marketing Updates', desc: 'Product news and updates' },
                        { title: 'Security Alerts', desc: 'Account security notifications' },
                      ].map((item, index) => (
                        <div key={index} className="flex items-center justify-between p-4 bg-gray-50 rounded-xl">
                          <div>
                            <div className="font-medium text-gray-900">{item.title}</div>
                            <div className="text-sm text-gray-500">{item.desc}</div>
                          </div>
                          <label className="relative inline-flex items-center cursor-pointer">
                            <input type="checkbox" className="sr-only peer" defaultChecked />
                            <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-purple-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-purple-600"></div>
                          </label>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {activeTab === 'appearance' && (
                  <div className="space-y-6">
                    <h3 className="text-2xl font-bold text-gray-900">Appearance Settings</h3>
                    
                    <div className="grid grid-cols-3 gap-4">
                      {['Light', 'Dark', 'Auto'].map((theme) => (
                        <div key={theme} className="p-4 border-2 border-gray-200 rounded-xl hover:border-purple-300 cursor-pointer transition-colors">
                          <div className="w-full h-20 bg-gradient-to-br from-gray-100 to-gray-200 rounded-lg mb-3"></div>
                          <div className="text-center font-medium">{theme}</div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {activeTab === 'billing' && (
                  <div className="space-y-6">
                    <h3 className="text-2xl font-bold text-gray-900">Billing & Subscription</h3>
                    
                    <div className="bg-gradient-to-r from-purple-600 to-blue-600 rounded-2xl p-6 text-white">
                      <div className="flex items-center justify-between">
                        <div>
                          <div className="text-2xl font-bold">{user.plan} Plan</div>
                          <div className="text-white/80">$29/month • Billed annually</div>
                        </div>
                        <Crown className="w-12 h-12 text-white/80" />
                      </div>
                      <div className="mt-4 flex items-center space-x-4">
                        <Shield className="w-5 h-5" />
                        <span>Next billing: January 15, 2025</span>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-6">
                      <button className="p-4 border border-gray-200 rounded-xl hover:border-purple-300 transition-colors text-left">
                        <Globe className="w-6 h-6 text-purple-600 mb-2" />
                        <div className="font-medium">Payment Method</div>
                        <div className="text-sm text-gray-500">•••• •••• •••• 4242</div>
                      </button>
                      <button className="p-4 border border-gray-200 rounded-xl hover:border-purple-300 transition-colors text-left">
                        <Zap className="w-6 h-6 text-purple-600 mb-2" />
                        <div className="font-medium">Usage</div>
                        <div className="text-sm text-gray-500">47 of 100 posts</div>
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};