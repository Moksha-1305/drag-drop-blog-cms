import React from 'react';
import { motion } from 'framer-motion';
import { Type, Image, Quote, List, Minus, AlignLeft, Sparkles, Crown } from 'lucide-react';

interface SidebarProps {
  onDragStart: (e: React.DragEvent, type: string) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ onDragStart }) => {
  const contentBlocks = [
    {
      type: 'heading',
      icon: Type,
      label: 'Heading',
      description: 'Add elegant titles and section headers',
      premium: false,
    },
    {
      type: 'paragraph',
      icon: AlignLeft,
      label: 'Paragraph',
      description: 'Rich text content with premium formatting',
      premium: false,
    },
    {
      type: 'image',
      icon: Image,
      label: 'Image',
      description: 'High-resolution images with smart optimization',
      premium: false,
    },
    {
      type: 'quote',
      icon: Quote,
      label: 'Quote',
      description: 'Stunning blockquotes with custom styling',
      premium: true,
    },
    {
      type: 'list',
      icon: List,
      label: 'List',
      description: 'Beautiful bulleted and numbered lists',
      premium: true,
    },
    {
      type: 'divider',
      icon: Minus,
      label: 'Divider',
      description: 'Elegant section separators',
      premium: false,
    },
  ];

  return (
    <div className="w-80 bg-gradient-to-b from-gray-50 to-white border-r border-gray-200/50 p-6 overflow-y-auto">
      <div className="mb-8">
        <div className="flex items-center space-x-2 mb-3">
          <div className="p-2 bg-gradient-to-br from-purple-600 to-blue-600 rounded-lg">
            <Sparkles className="w-5 h-5 text-white" />
          </div>
          <h2 className="text-xl font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
            Premium Blocks
          </h2>
        </div>
        <p className="text-sm text-gray-600 leading-relaxed">
          Drag and drop these luxury content blocks to craft your masterpiece
        </p>
      </div>
      
      <div className="space-y-4">
        {contentBlocks.map((block, index) => {
          const Icon = block.icon;
          return (
            <motion.div
              key={block.type}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              draggable
              onDragStart={(e) => onDragStart(e, block.type)}
              className={`relative bg-white rounded-2xl p-5 border-2 transition-all duration-300 cursor-grab active:cursor-grabbing group hover:shadow-xl ${
                block.premium 
                  ? 'border-gradient-to-r from-purple-200 to-blue-200 hover:from-purple-300 hover:to-blue-300' 
                  : 'border-gray-200 hover:border-gray-300'
              }`}
              whileHover={{ scale: 1.02, y: -2 }}
              whileTap={{ scale: 0.98 }}
            >
              {block.premium && (
                <div className="absolute -top-2 -right-2 p-1 bg-gradient-to-r from-purple-600 to-blue-600 rounded-full">
                  <Crown className="w-3 h-3 text-white" />
                </div>
              )}
              
              <div className="flex items-start space-x-4">
                <div className={`flex-shrink-0 p-3 rounded-xl transition-all group-hover:scale-110 ${
                  block.premium 
                    ? 'bg-gradient-to-br from-purple-100 to-blue-100 group-hover:from-purple-200 group-hover:to-blue-200' 
                    : 'bg-gray-100 group-hover:bg-gray-200'
                }`}>
                  <Icon className={`w-6 h-6 ${
                    block.premium ? 'text-purple-600' : 'text-gray-600'
                  }`} />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center space-x-2 mb-2">
                    <h3 className="font-semibold text-gray-900">
                      {block.label}
                    </h3>
                    {block.premium && (
                      <span className="px-2 py-1 bg-gradient-to-r from-purple-600 to-blue-600 text-white text-xs rounded-full font-medium">
                        PRO
                      </span>
                    )}
                  </div>
                  <p className="text-sm text-gray-600 leading-relaxed">
                    {block.description}
                  </p>
                </div>
              </div>
              
              {/* Drag indicator */}
              <div className="absolute inset-0 border-2 border-dashed border-transparent group-hover:border-purple-300 rounded-2xl transition-all pointer-events-none" />
            </motion.div>
          );
        })}
      </div>

      {/* Premium Features */}
      <div className="mt-8 p-4 bg-gradient-to-br from-purple-50 to-blue-50 rounded-2xl border border-purple-200">
        <div className="flex items-center space-x-2 mb-2">
          <Crown className="w-4 h-4 text-purple-600" />
          <span className="font-semibold text-purple-900">Premium Features</span>
        </div>
        <ul className="text-sm text-purple-700 space-y-1">
          <li>• Advanced styling options</li>
          <li>• Custom animations</li>
          <li>• Priority support</li>
          <li>• Unlimited exports</li>
        </ul>
      </div>
    </div>
  );
};