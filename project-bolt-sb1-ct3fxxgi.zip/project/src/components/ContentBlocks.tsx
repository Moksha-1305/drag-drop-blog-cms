import React, { useState, useEffect, useRef } from 'react';
import { ContentBlock } from '../types';
import { GripVertical, Trash2, Edit3, Plus } from 'lucide-react';

interface ContentBlockProps {
  block: ContentBlock;
  onUpdate: (block: ContentBlock) => void;
  onDelete: (id: string) => void;
  onDragStart: (e: React.DragEvent, block: ContentBlock) => void;
  onDragOver: (e: React.DragEvent) => void;
  onDrop: (e: React.DragEvent, targetId: string) => void;
  isDragging: boolean;
}

export const ContentBlockComponent: React.FC<ContentBlockProps> = ({
  block,
  onUpdate,
  onDelete,
  onDragStart,
  onDragOver,
  onDrop,
  isDragging,
}) => {
  const [isEditing, setIsEditing] = useState(false);
  const [content, setContent] = useState(block.content);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isEditing && textareaRef.current) {
      textareaRef.current.focus();
      textareaRef.current.setSelectionRange(content.length, content.length);
    }
    if (isEditing && inputRef.current) {
      inputRef.current.focus();
      inputRef.current.setSelectionRange(content.length, content.length);
    }
  }, [isEditing, content]);

  const handleSave = () => {
    onUpdate({
      ...block,
      content: content.trim(),
    });
    setIsEditing(false);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey && block.type !== 'paragraph') {
      e.preventDefault();
      handleSave();
    }
    if (e.key === 'Escape') {
      setContent(block.content);
      setIsEditing(false);
    }
  };

  const renderContent = () => {
    if (isEditing) {
      switch (block.type) {
        case 'heading':
          return (
            <input
              ref={inputRef}
              type="text"
              value={content}
              onChange={(e) => setContent(e.target.value)}
              onBlur={handleSave}
              onKeyDown={handleKeyDown}
              className="w-full text-2xl font-bold text-gray-900 bg-transparent border-none focus:outline-none focus:ring-0 p-0"
              placeholder="Enter heading..."
            />
          );
        case 'paragraph':
        case 'quote':
          return (
            <textarea
              ref={textareaRef}
              value={content}
              onChange={(e) => setContent(e.target.value)}
              onBlur={handleSave}
              onKeyDown={handleKeyDown}
              className="w-full bg-transparent border-none focus:outline-none focus:ring-0 p-0 resize-none overflow-hidden"
              placeholder={block.type === 'quote' ? 'Enter quote...' : 'Enter text...'}
              rows={Math.max(2, content.split('\n').length)}
            />
          );
        case 'image':
          return (
            <input
              ref={inputRef}
              type="text"
              value={content}
              onChange={(e) => setContent(e.target.value)}
              onBlur={handleSave}
              onKeyDown={handleKeyDown}
              className="w-full bg-transparent border-none focus:outline-none focus:ring-0 p-0"
              placeholder="Enter image URL..."
            />
          );
        case 'list':
          return (
            <textarea
              ref={textareaRef}
              value={content}
              onChange={(e) => setContent(e.target.value)}
              onBlur={handleSave}
              onKeyDown={handleKeyDown}
              className="w-full bg-transparent border-none focus:outline-none focus:ring-0 p-0 resize-none overflow-hidden"
              placeholder="Enter list items (one per line)..."
              rows={Math.max(2, content.split('\n').length)}
            />
          );
        default:
          return null;
      }
    }

    switch (block.type) {
      case 'heading':
        return (
          <h2 className="text-2xl font-bold text-gray-900 leading-tight">
            {block.content || 'Click to edit heading'}
          </h2>
        );
      case 'paragraph':
        return (
          <p className="text-gray-700 leading-relaxed whitespace-pre-wrap">
            {block.content || 'Click to edit paragraph'}
          </p>
        );
      case 'image':
        return block.content ? (
          <img
            src={block.content}
            alt="Blog content"
            className="w-full h-auto rounded-lg shadow-sm"
            onError={(e) => {
              e.currentTarget.src = 'https://via.placeholder.com/600x300/f3f4f6/6b7280?text=Image+Not+Found';
            }}
          />
        ) : (
          <div className="w-full h-48 bg-gray-100 rounded-lg flex items-center justify-center text-gray-500">
            Click to add image URL
          </div>
        );
      case 'quote':
        return (
          <blockquote className="border-l-4 border-blue-500 pl-6 py-2 italic text-gray-700 text-lg">
            {block.content || 'Click to edit quote'}
          </blockquote>
        );
      case 'list':
        return (
          <ul className="space-y-2">
            {(block.content || 'Click to edit list').split('\n').filter(item => item.trim()).map((item, index) => (
              <li key={index} className="flex items-start space-x-2">
                <span className="w-2 h-2 bg-blue-500 rounded-full mt-2 flex-shrink-0"></span>
                <span className="text-gray-700">{item.trim()}</span>
              </li>
            ))}
          </ul>
        );
      case 'divider':
        return <hr className="border-gray-300 my-6" />;
      default:
        return null;
    }
  };

  return (
    <div
      className={`group relative bg-white rounded-lg border-2 transition-all duration-200 ${
        isDragging 
          ? 'border-blue-400 shadow-lg opacity-50' 
          : 'border-gray-200 hover:border-gray-300 hover:shadow-md'
      }`}
      draggable
      onDragStart={(e) => onDragStart(e, block)}
      onDragOver={onDragOver}
      onDrop={(e) => onDrop(e, block.id)}
    >
      {/* Control Bar */}
      <div className="absolute -top-2 -right-2 flex items-center space-x-1 opacity-0 group-hover:opacity-100 transition-opacity duration-200">
        <button
          onClick={() => setIsEditing(!isEditing)}
          className="p-2 bg-white border border-gray-300 rounded-full shadow-sm hover:bg-gray-50 transition-colors"
          title="Edit content"
        >
          <Edit3 className="w-4 h-4 text-gray-600" />
        </button>
        <button
          onClick={() => onDelete(block.id)}
          className="p-2 bg-white border border-gray-300 rounded-full shadow-sm hover:bg-red-50 hover:border-red-300 transition-colors"
          title="Delete block"
        >
          <Trash2 className="w-4 h-4 text-red-600" />
        </button>
      </div>

      {/* Drag Handle */}
      <div className="absolute -left-2 top-1/2 transform -translate-y-1/2 opacity-0 group-hover:opacity-100 transition-opacity duration-200">
        <div className="p-1 bg-white border border-gray-300 rounded shadow-sm cursor-grab active:cursor-grabbing">
          <GripVertical className="w-4 h-4 text-gray-400" />
        </div>
      </div>

      {/* Content */}
      <div
        className={`p-6 ${isEditing ? 'bg-blue-50' : ''} rounded-lg transition-colors duration-200`}
        onClick={() => !isEditing && setIsEditing(true)}
      >
        {renderContent()}
      </div>

      {/* Drop Zone Indicators */}
      <div className="absolute -top-1 left-0 right-0 h-2 bg-blue-500 rounded-full opacity-0 transition-opacity duration-200 pointer-events-none" />
      <div className="absolute -bottom-1 left-0 right-0 h-2 bg-blue-500 rounded-full opacity-0 transition-opacity duration-200 pointer-events-none" />
    </div>
  );
};

interface ContentEditorProps {
  blocks: ContentBlock[];
  onBlocksChange: (blocks: ContentBlock[]) => void;
  onAddBlock: (type: string) => void;
  isPreviewMode: boolean;
}

export const ContentEditor: React.FC<ContentEditorProps> = ({
  blocks,
  onBlocksChange,
  onAddBlock,
  isPreviewMode,
}) => {
  const [draggedBlock, setDraggedBlock] = useState<ContentBlock | null>(null);
  const [draggedType, setDraggedType] = useState<string | null>(null);
  const [dragOverIndex, setDragOverIndex] = useState<number | null>(null);

  const handleDragStart = (e: React.DragEvent, block: ContentBlock) => {
    setDraggedBlock(block);
    e.dataTransfer.effectAllowed = 'move';
  };

  const handleSidebarDragStart = (e: React.DragEvent, type: string) => {
    setDraggedType(type);
    e.dataTransfer.effectAllowed = 'copy';
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = draggedType ? 'copy' : 'move';
  };

  const handleDrop = (e: React.DragEvent, targetId?: string) => {
    e.preventDefault();
    
    if (draggedType) {
      // Adding new block from sidebar
      const targetIndex = targetId ? blocks.findIndex(b => b.id === targetId) : blocks.length;
      const newBlock: ContentBlock = {
        id: Date.now().toString(),
        type: draggedType as ContentBlock['type'],
        content: '',
        order: targetIndex,
        styles: {},
      };
      
      const newBlocks = [...blocks];
      newBlocks.splice(targetIndex, 0, newBlock);
      
      // Update order for all blocks
      newBlocks.forEach((block, index) => {
        block.order = index;
      });
      
      onBlocksChange(newBlocks);
      setDraggedType(null);
    } else if (draggedBlock && targetId) {
      // Reordering existing blocks
      const draggedIndex = blocks.findIndex(b => b.id === draggedBlock.id);
      const targetIndex = blocks.findIndex(b => b.id === targetId);
      
      if (draggedIndex !== -1 && targetIndex !== -1 && draggedIndex !== targetIndex) {
        const newBlocks = [...blocks];
        const [removed] = newBlocks.splice(draggedIndex, 1);
        newBlocks.splice(targetIndex, 0, removed);
        
        // Update order for all blocks
        newBlocks.forEach((block, index) => {
          block.order = index;
        });
        
        onBlocksChange(newBlocks);
      }
    }
    
    setDraggedBlock(null);
    setDragOverIndex(null);
  };

  const handleBlockUpdate = (updatedBlock: ContentBlock) => {
    const newBlocks = blocks.map(block =>
      block.id === updatedBlock.id ? updatedBlock : block
    );
    onBlocksChange(newBlocks);
  };

  const handleBlockDelete = (blockId: string) => {
    const newBlocks = blocks.filter(block => block.id !== blockId);
    // Update order for remaining blocks
    newBlocks.forEach((block, index) => {
      block.order = index;
    });
    onBlocksChange(newBlocks);
  };

  if (isPreviewMode) {
    return (
      <div className="max-w-4xl mx-auto px-6 py-8">
        <div className="space-y-6">
          {blocks.map((block) => (
            <div key={block.id} className="animate-fadeIn">
              {(() => {
                switch (block.type) {
                  case 'heading':
                    return (
                      <h2 className="text-3xl font-bold text-gray-900 leading-tight">
                        {block.content || 'Untitled'}
                      </h2>
                    );
                  case 'paragraph':
                    return (
                      <p className="text-gray-700 leading-relaxed text-lg whitespace-pre-wrap">
                        {block.content || ''}
                      </p>
                    );
                  case 'image':
                    return block.content ? (
                      <img
                        src={block.content}
                        alt="Blog content"
                        className="w-full h-auto rounded-xl shadow-md"
                        onError={(e) => {
                          e.currentTarget.src = 'https://via.placeholder.com/800x400/f3f4f6/6b7280?text=Image+Not+Found';
                        }}
                      />
                    ) : null;
                  case 'quote':
                    return (
                      <blockquote className="border-l-4 border-blue-500 pl-8 py-4 italic text-gray-700 text-xl bg-blue-50 rounded-r-lg">
                        {block.content || ''}
                      </blockquote>
                    );
                  case 'list':
                    return (
                      <ul className="space-y-3">
                        {(block.content || '').split('\n').filter(item => item.trim()).map((item, index) => (
                          <li key={index} className="flex items-start space-x-3">
                            <span className="w-2 h-2 bg-blue-500 rounded-full mt-3 flex-shrink-0"></span>
                            <span className="text-gray-700 text-lg">{item.trim()}</span>
                          </li>
                        ))}
                      </ul>
                    );
                  case 'divider':
                    return <hr className="border-gray-300 my-8" />;
                  default:
                    return null;
                }
              })()}
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-6 py-8">
      <div 
        className="min-h-screen space-y-6"
        onDragOver={handleDragOver}
        onDrop={(e) => handleDrop(e)}
      >
        {blocks.length === 0 ? (
          <div className="text-center py-16">
            <div className="w-16 h-16 mx-auto mb-4 bg-blue-100 rounded-full flex items-center justify-center">
              <Plus className="w-8 h-8 text-blue-600" />
            </div>
            <h3 className="text-xl font-semibold text-gray-900 mb-2">
              Start Building Your Blog Post
            </h3>
            <p className="text-gray-600 mb-6">
              Drag content blocks from the sidebar to begin creating your blog post
            </p>
            <div className="flex flex-wrap gap-2 justify-center">
              {['heading', 'paragraph', 'image', 'quote', 'list'].map((type) => (
                <button
                  key={type}
                  onClick={() => onAddBlock(type)}
                  className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors capitalize"
                >
                  Add {type}
                </button>
              ))}
            </div>
          </div>
        ) : (
          blocks.map((block) => (
            <ContentBlockComponent
              key={block.id}
              block={block}
              onUpdate={handleBlockUpdate}
              onDelete={handleBlockDelete}
              onDragStart={handleDragStart}
              onDragOver={handleDragOver}
              onDrop={handleDrop}
              isDragging={draggedBlock?.id === block.id}
            />
          ))
        )}
      </div>
    </div>
  );
};

// Export the drag start handler for the sidebar
export const useDragHandlers = () => {
  const handleSidebarDragStart = (e: React.DragEvent, type: string) => {
    e.dataTransfer.setData('text/plain', type);
    e.dataTransfer.effectAllowed = 'copy';
  };

  return { handleSidebarDragStart };
};