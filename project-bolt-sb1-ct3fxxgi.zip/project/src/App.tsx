import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Header } from './components/Header';
import { Sidebar } from './components/Sidebar';
import { ContentEditor, useDragHandlers } from './components/ContentBlocks';
import { AuthModal } from './components/AuthModal';
import { SettingsModal } from './components/SettingsModal';
import { useBlogState } from './hooks/useBlogState';
import { useAuth } from './hooks/useAuth';

function App() {
  const {
    blogTitle,
    blocks,
    isPreviewMode,
    isSaving,
    isPublishing,
    addBlock,
    updateBlocks,
    saveBlog,
    publishBlog,
    togglePreview,
    updateTitle,
  } = useBlogState();

  const {
    user,
    isLoading: authLoading,
    error: authError,
    login,
    register,
    logout,
    isAuthenticated,
  } = useAuth();

  const { handleSidebarDragStart } = useDragHandlers();
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [showSettingsModal, setShowSettingsModal] = useState(false);

  // Show auth modal if not authenticated
  React.useEffect(() => {
    if (!authLoading && !isAuthenticated) {
      setShowAuthModal(true);
    }
  }, [authLoading, isAuthenticated]);

  const handleSettings = () => {
    setShowSettingsModal(true);
  };

  if (authLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-blue-50 flex items-center justify-center">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="text-center"
        >
          <div className="w-16 h-16 mx-auto mb-4 bg-gradient-to-r from-purple-600 to-blue-600 rounded-2xl flex items-center justify-center">
            <div className="w-8 h-8 border-3 border-white/30 border-t-white rounded-full animate-spin" />
          </div>
          <h2 className="text-2xl font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent mb-2">
            BlogCraft Elite
          </h2>
          <p className="text-gray-600">Loading your premium experience...</p>
        </motion.div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <>
        <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-blue-50 flex items-center justify-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center max-w-md mx-auto p-8"
          >
            <div className="w-20 h-20 mx-auto mb-6 bg-gradient-to-r from-purple-600 to-blue-600 rounded-3xl flex items-center justify-center">
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
                className="text-white text-3xl"
              >
                ✨
              </motion.div>
            </div>
            <h1 className="text-4xl font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent mb-4">
              BlogCraft Elite
            </h1>
            <p className="text-xl text-gray-600 mb-8">
              The most luxurious way to create stunning blog content
            </p>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => setShowAuthModal(true)}
              className="px-8 py-4 bg-gradient-to-r from-purple-600 to-blue-600 text-white rounded-2xl font-semibold text-lg shadow-2xl hover:shadow-3xl transition-all"
            >
              Start Creating
            </motion.button>
          </motion.div>
        </div>

        <AuthModal
          isOpen={showAuthModal}
          onClose={() => setShowAuthModal(false)}
          onLogin={login}
          onRegister={register}
          isLoading={authLoading}
          error={authError}
        />
      </>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-white to-purple-50">
      <Header
        onSave={saveBlog}
        onPreview={togglePreview}
        onPublish={publishBlog}
        onSettings={handleSettings}
        isPreviewMode={isPreviewMode}
        blogTitle={blogTitle}
        onTitleChange={updateTitle}
        user={user!}
        onLogout={logout}
        isSaving={isSaving}
        isPublishing={isPublishing}
      />
      
      <div className="flex">
        <AnimatePresence>
          {!isPreviewMode && (
            <motion.div
              initial={{ x: -320, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              exit={{ x: -320, opacity: 0 }}
              transition={{ type: "spring", damping: 25, stiffness: 200 }}
            >
              <Sidebar onDragStart={handleSidebarDragStart} />
            </motion.div>
          )}
        </AnimatePresence>
        
        <main className={`flex-1 transition-all duration-500 ${
          isPreviewMode 
            ? 'bg-white' 
            : 'bg-gradient-to-br from-gray-50 via-white to-purple-50'
        }`}>
          <ContentEditor
            blocks={blocks}
            onBlocksChange={updateBlocks}
            onAddBlock={addBlock}
            isPreviewMode={isPreviewMode}
          />
        </main>
      </div>
      
      {/* Loading overlays */}
      <AnimatePresence>
        {(isSaving || isPublishing) && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50"
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-white rounded-2xl p-8 flex items-center space-x-4 shadow-2xl"
            >
              <div className="w-8 h-8 border-3 border-purple-200 border-t-purple-600 rounded-full animate-spin" />
              <div>
                <div className="font-semibold text-gray-900">
                  {isSaving ? 'Saving your masterpiece...' : 'Publishing to the world...'}
                </div>
                <div className="text-sm text-gray-500">
                  {isSaving ? 'Securing your content in our premium vault' : 'Making your blog live for everyone to see'}
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <SettingsModal
        isOpen={showSettingsModal}
        onClose={() => setShowSettingsModal(false)}
        user={user!}
      />
    </div>
  );
}

export default App;